# Filter Bot (Pyrogram + MongoDB)

Telegram group filter bot: save **text / media filters with inline buttons**; when anyone sends the keyword in the group, the bot replies with the saved filter. Includes **/connect** so admins can manage a group's filters from the bot's PM.

## Setup

1. Python **3.10 - 3.12** (3.11 recommended).
2. `pip install -r requirements.txt`
3. Copy `.env.example` to `.env` and fill in `API_ID`, `API_HASH` (my.telegram.org), `BOT_TOKEN` (@BotFather), `MONGO_URI` (MongoDB Atlas or local).
4. In @BotFather: `/setprivacy` -> **Disable** (so the bot can read group messages), then add the bot to your group (admin recommended).
5. `python bot.py`

## Commands

| Command | What it does |
|---|---|
| `/filter keyword` (reply to message/media) | Save that message as a filter |
| `/filter keyword text` | Save a text filter |
| `/filter "two words" ...` | Keyword with spaces |
| `/filters` | List filters |
| `/del keyword` | Delete one |
| `/delall` | Delete all (group owner only) |
| `/connect` (in group) or `/connect -100id` (in PM) | Link group to your PM |
| `/connections` | Switch / remove connected groups |
| `/disconnect` | Disconnect |

## Buttons

```
[Google](buttonurl:https://google.com)
[Row 1 btn](buttonurl:https://a.com)
[Same row btn](buttonurl:https://b.com:same)
```

Put the button lines in the text/caption of the message you're saving, or after the keyword in the command.

Supports photo, video, GIF, document, audio, voice, video note and sticker filters. Keyword matching is case-insensitive whole-word (longest keyword wins).
